Samples in this folder are for the Pluralsight course, C# Collections, Module 8-Enumerators,
by Simon Robinson.

They have been created in VS2010 and verified that they load in VS2013.

Samples Included:
Enumerating: Demonstrates how to enumerate a collection explicitly using IEnumerator methods
EnumerateItems-Foreach: Demonstrates using a foreach loop to achieve the same results as the Enumerating sample
Enumerate-While-Changing: Demonstrates that a foreach loop over a List<string> throws an exception if the list is modified
Implement-Enumerator: Demonstrates how to implement a very simple enumerator using yield return
Covariance: Demonstrates casts that are possible using covariance
