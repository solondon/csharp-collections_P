Samples in this folder are for the Pluralsight course, C# Collections, Module 11 - Multidimensional Arrays, Rank and Bounds
by Simon Robinson.

They have been created in VS2010 and verified that they load in VS2013.

Samples Included:
Multidimensional: Demonstrates basic usage of a multidimensional array
Bounds: Modifies the multidimensional project to use GetLowerBound() and GetUpperBound()
JaggedArrays: Modifies the multidimensional project to use a jagged array instead of a multidimensional array
