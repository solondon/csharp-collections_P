Samples in this folder are for the Pluralsight course, C# Collections, Module 7 - Linked Lists,
by Simon Robinson.

They have been created in VS2010 and verified that they load in VS2013.

Samples Included:
LinkedListDemo: Demonstrates use of a linked list
Stacks: Demonstrates use of a linked stack
Queus: Demonstrates use of a linked queue

