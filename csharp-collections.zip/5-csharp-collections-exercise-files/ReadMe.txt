Samples in this folder are for the Pluralsight course, C# Collections, Module 5 - Collection Interfaces, by Simon Robinson.

They have been created in VS2010 and verified that they load in VS2013.

Samples Included:
Count: Shows the various ways of counting elements in an array
AddElement: Shows that you can't add an element to an array using the ICollection interface
but you can still replace an element by casting the ICollection interface reference.
