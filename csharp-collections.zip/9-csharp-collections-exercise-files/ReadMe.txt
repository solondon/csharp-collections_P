Samples in this folder are for the Pluralsight course, C# Collections, Module 9-Sets,
by Simon Robinson.

They have been created in VS2010 and verified that they load in VS2013.

Samples Included:
HashSetBasics: Demos basics of using HashSet<T>, including the fact that elements are unique
HashSetComparer: Adds a custom comparer to a HashSet<T>
Intersect: Shows using HashSet<T> to do an intersection and other operations
SetEquals: Shows checking whether two collections contain the same elements
SetComparison: Shows some of the other set comparison operations
SortedSetDemo: Shows using a sorted set, including adding a custom comparer
