Samples in this folder are for the Pluralsight course, C# Collections, Module 4 - The Array Type, by Simon Robinson.

They have been created in VS2010 and verified that they load in VS2013.

Samples Included:
ArraysAsRefTypes: Demonstrates how arrays are reference types and act as such
ArrayTyping: Shows the types of arrays and how instances of derived types may be stored in them
ArrayCovariance: Demonstrates array covariance
ArrayCopy: Shows copying an array
ReverseArray: Shows reversing an array
SortArray: Shows sorting an array
FindElements: Shows finding the elements in an array
BinarySearch: Shows finding elements in an array using binary search

